## Boots5, a theme by ThemeWagon team.
---
Get the figma design file here:
[https://www.figma.com/file/1TGwGU32euN4ltH9KFTVot/Boots4-%F0%9F%91%A2%F0%9F%91%A2%F0%9F%91%A2%F0%9F%91%A2-Redesign-(v.1.2)?node-id=777%3A638]
